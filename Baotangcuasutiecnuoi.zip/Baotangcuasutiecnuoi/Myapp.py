from PyQt6.QtWidgets import QApplication
from Museumex import MainApp
app = QApplication([])
myWindow = MainApp()
myWindow.show()
app.exec()
